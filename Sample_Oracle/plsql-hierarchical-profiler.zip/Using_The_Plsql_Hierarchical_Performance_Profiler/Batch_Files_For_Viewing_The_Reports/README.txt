If you want to use these .bat files, you'll need to edit
them to reflect the directories where you expanded the zip.

I found it convenient to make a shortcut for each of these
and to put the shortcuts into a folder on this dir:

  C:\Documents and Settings\All Users\Start Menu
