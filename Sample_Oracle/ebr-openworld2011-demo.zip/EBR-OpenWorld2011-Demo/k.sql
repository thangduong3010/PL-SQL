@@Do_Kill_All_Foreground_Sessions
