-- Comment out, or uncomment these SQL*Plus commands
-- according to taste.

--PROMPT Pausing...
--PAUSE
