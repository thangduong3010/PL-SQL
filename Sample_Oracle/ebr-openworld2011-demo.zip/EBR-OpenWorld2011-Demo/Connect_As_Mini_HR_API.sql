CONNECT Mini_HR_API/p@11202
@@My_Glogin
