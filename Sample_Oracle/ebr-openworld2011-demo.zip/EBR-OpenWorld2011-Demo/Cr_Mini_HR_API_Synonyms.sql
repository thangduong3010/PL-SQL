@@Connect_As_Mini_HR_API

create synonym Mini_HR_API.Emp_Mtnc for Mini_HR_Owner.Emp_Mtnc
/
EXECUTE x.p('Mini_HR_API synonyms created')
