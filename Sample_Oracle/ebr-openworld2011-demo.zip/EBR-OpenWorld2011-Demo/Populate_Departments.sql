<<Insert_Into_Departments>>
begin

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(10, 'Administration', '200', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(20, 'Marketing', '201', '1800')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(30, 'Purchasing', '114', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(40, 'Human Resources', '203', '2400')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(50, 'Shipping', '121', '1500')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(60, 'IT', '103', '1400')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(70, 'Public Relations', '204', '2700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(80, 'Sales', '145', '2500')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(90, 'Executive', '100', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(100, 'Finance', '108', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(110, 'Accounting', '205', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(120, 'Treasury', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(130, 'Corporate Tax', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(140, 'Control And Credit', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(150, 'Shareholder Services', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(160, 'Benefits', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(170, 'Manufacturing', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(180, 'Construction', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(190, 'Contracting', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(200, 'Operations', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(210, 'IT Support', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(220, 'NOC', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(230, 'IT Helpdesk', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(240, 'Government Sales', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(250, 'Retail Sales', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(260, 'Recruiting', '', '1700')
;

insert into Departments(Department_ID, Department_Name, Manager_ID, Location_ID)

  values(270, 'Payroll', '', '1700')
;

commit;
end Insert_Into_Departments;
/
