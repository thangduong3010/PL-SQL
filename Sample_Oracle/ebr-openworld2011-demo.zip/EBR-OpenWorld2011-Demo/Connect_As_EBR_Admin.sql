CONNECT EBR_Admin/p@11202
@@My_Glogin
