-- Comment out, or uncomment this SQL*Plus command
-- according to taste.

--CLEAR SCREEN
