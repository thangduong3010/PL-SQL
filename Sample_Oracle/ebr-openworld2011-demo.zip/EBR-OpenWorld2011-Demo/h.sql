-- Goes from scratch to hotrollover

@@r
@@1_EBR1_Task__Cr_New_Edition_Do_DDLs_Apply_Transform
@@3_EBR1_Task__Use_Post_Upgrade_Mini_HR_App
