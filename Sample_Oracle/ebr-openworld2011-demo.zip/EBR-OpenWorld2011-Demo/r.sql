-- Reset the demo. Can be run at any point UNLESS 5_EBR2_Task__Null_Upgrade
-- has been run. See the comments in Task_Overview.

@@0a_Prep_Task__Install_Pre_11gR2_Mini_HR_App
@@0c_Prep_Task__Ready_Mini_HR_App_For_EBR
@@0d_Prep_Task__Use_Pre_Upgrade_Mini_HR_App
