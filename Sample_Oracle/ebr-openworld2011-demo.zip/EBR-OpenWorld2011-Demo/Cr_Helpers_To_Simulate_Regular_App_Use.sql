-- Just to allow demo of concurrent live activity.
@@Connect_As_Sys
@@Cr_Do_Random_DML
@@Cr_Submit_Random_Updates_Job

EXECUTE x.p('Helper procedures to simulate regular app use created.')
