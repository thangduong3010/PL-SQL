/** 
 *  @author  : Shrinivas Bhat Padamar
 *  @version : 1.0 
 * 
 *  Name of the Application         :  update.sql
 *  Creation/Modification History   :  25-Nov-2004
 * 
 *  Overview of  Package/Sample     : Query used to update the row in the USERINFO table
 *    
 **/

UPDATE userinfo SET phone='650.221.2019',email='@johnemails.com', password='john'  WHERE username='John ';