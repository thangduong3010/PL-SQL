(1) There are 3 files enclosed - a specification sql file, a wrapped 
implementation file and a sample session. Follow the example from the sample 
session. Instead of individual inserts into the temp history table, you can 
also do "insert as select" for bulk inserts into the temporary history table.

       (1) Install the packages as sysdba
           sqlplus / as sysdba
           SQL> @dbms_fda_import.sql
           SQL> @prvt_fda_import.plb
       (2) Create a flashback archive with the required retention to
       cover the history to be imported and make sure the base  table
       is enabled for flashback archive

       (3) Create time to scn mappings for times in the past:
          sqlplus scott/tiger
          SQL> execute dbms_fba_mappings.extend_mappings();
          This command will ensure that the time to scn mappings for
       times in the past are added.

       (4) Create a temp_history table of the appropriate format
           SQL> execute
       dbms_fba_import.create_temp_history_table('scott','test');
           A new table called temp_history will be created with the
       required columns.

       (5) Fill temp_history with the history to be imported. This
       table will have new metadata columns

           RID which represents the ROWID (ok to leave as NULL)

           XID which represents the XID of the creator of the version
       (ok to leave as NULL)

          Operation (''I' or 'U' representing the creating change, ok
       to leave NULL)

          STARTSCN and ENDSCN (representing the SCN when the version
       was created and the SCN when the version was destroyed by
       deletion or another update).

         Use TIMESTAMP_TO_SCN to convert times to SCN. It is assumed that
         your old history has start and end times of versions.It should be
         possible to convert other formats to this format.



   (5) Use import_history to import the old history into the flashback
   archive:
       SQL> execute dbms_fba_import.import_history('scott','test');

   The old history is now available for access through 'as of' and
   versions queries. 
