/* This package extends time mappings to times in the past */
CREATE OR REPLACE PACKAGE dbms_fda_mappings AUTHID DEFINER as
procedure extend_mappings;
END;
/
show errors;

/* This package is used to import old history into Flashback Data Archive */
CREATE OR REPLACE PACKAGE dbms_fda_import AUTHID CURRENT_USER AS
/* This procedure creates a table called temp_history with the 
 * correct definition in the given schema.
 */
procedure create_temp_history_table
(owner_name1 IN VARCHAR2, table_name1 IN VARCHAR2) ;
/* This procedure imports history from a table called temp_history 
 * in the given schema.
 */
procedure import_history
(owner_name1 IN VARCHAR2, table_name1 IN VARCHAR2) ;
END;
/
show errors;
GRANT EXECUTE ON dbms_fda_mappings TO PUBLIC;
CREATE OR REPLACE PUBLIC SYNONYM dbms_fda_mappings FOR sys.dbms_fda_mappings;
GRANT EXECUTE ON dbms_fda_import TO PUBLIC;
CREATE OR REPLACE PUBLIC SYNONYM dbms_fda_import FOR sys.dbms_fda_import;
