set echo on;

@tbl
@spec
@body
@capi

quit;
